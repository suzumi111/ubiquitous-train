
import streamlit as st
import pandas as pd
import pickle
import pytesseract
from PIL import Image
import io

# Load model
with open("trained_model.xgb", "rb") as f:
    model = pickle.load(f)

# Pitch code map
pitch_map = {
    'l': 'batting',
    'r': 'neutral',
    's': 'bowling',
    'c': 'neutral'
}

def process_pitch_code(code):
    return pitch_map.get(str(code).strip().lower(), 'neutral')

def predict_best_xi(df):
    df['pitch'] = df['pitch'].apply(process_pitch_code)
    df['bat_order_score'] = (12 - df['batting_order']) * 1.5
    df['venue_bias'] = df['pitch'].map({'batting': 5, 'bowling': -5, 'neutral': 0}).fillna(0)
    df['feature'] = df['avg_points'] + df['bat_order_score'] + df['venue_bias']
    df['predicted'] = model.predict(df[['feature']])

    best_xi = df.sort_values(by='predicted', ascending=False).head(11).copy()
    best_xi.iloc[0, best_xi.columns.get_loc('predicted')] *= 2  # Captain
    best_xi.iloc[1, best_xi.columns.get_loc('predicted')] *= 1.5  # Vice Captain
    best_xi.sort_values(by='predicted', ascending=False, inplace=True)
    return best_xi

st.title("Dream11 Predictor with Screenshot & CSV Input")

input_method = st.radio("Choose Input Method", ["CSV Upload", "Screenshot OCR"])

if input_method == "CSV Upload":
    uploaded_file = st.file_uploader("Upload CSV", type="csv")
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        best_xi = predict_best_xi(df)
        st.subheader("Predicted Best XI")
        st.dataframe(best_xi[['player_name', 'team', 'avg_points', 'batting_order', 'predicted']])

        st.download_button(
            label="Download as Excel",
            data=best_xi.to_excel(index=False, engine='openpyxl'),
            file_name="best_xi_prediction.xlsx"
        )

elif input_method == "Screenshot OCR":
    image_file = st.file_uploader("Upload Screenshot (PNG, JPG)", type=['png', 'jpg', 'jpeg'])
    if image_file:
        image = Image.open(image_file)
        st.image(image, caption='Uploaded Screenshot', use_column_width=True)
        ocr_text = pytesseract.image_to_string(image)
        st.text_area("Extracted Text (editable)", ocr_text, height=200)

        st.info("Manual formatting of this OCR text into structured data may be required.")
        st.markdown("Expected format: player_name, team, avg_points, batting_order, pitch (l/r/s/c)")

        if st.button("Use OCR Data (Advanced Users Only)"):
            st.warning("Parsing from text requires structured OCR or manual adjustment. Not auto-parsing yet.")
